import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.cluster import DBSCAN , OPTICS , SpectralClustering,KMeans
from lifelines.statistics import logrank_test
import numpy as np
from lifelines import KaplanMeierFitter
from sklearn.manifold import TSNE
from collections import Counter

# df=pd.read_csv('F:/zs/data/ov/12emb/ov_patient.txt',sep='\t',header=None)
# #df=df[df[1]==1]
# df1=pd.read_csv('F:/zs/data/sample_survival/ov.txt',sep='\t')
# df2=pd.DataFrame(df1['bcr_patient_barcode'])
# df=pd.merge(df,df2,left_on=df[0],right_on=df2['bcr_patient_barcode'],how='inner')
# df=df.drop(['key_0',1,'bcr_patient_barcode'],axis=1)
# df=df.set_index(0)
# clustering=KMeans(n_clusters=6).fit(df)
# df['subtype'] = clustering.labels_
# df=df.sort_values(by='subtype')
# a=len(df[df['subtype']==0])
# b=len(df[df['subtype']==1])
# c=len(df[df['subtype']==2])
# d=len(df[df['subtype']==3])
# e=len(df[df['subtype']==4])
# f=len(df[df['subtype']==5])
# df=df.reset_index()
# data=df[[0,'subtype']]
# a=pd.merge(data,df1,left_on=df[0],right_on=df1['bcr_patient_barcode'],how='inner')
# data=pd.read_csv('F:/szs/data/TCGA_Clinical/ov/Clinical/nationwidechildrens.org_clinical_patient_ov.txt', sep='\t')
# data=data[["bcr_patient_barcode","gender","vital_status","last_contact_days_to","death_days_to"]]
# data=data.drop(data[data['last_contact_days_to'].isin(['[Completed]'])].index)#删除指定元素的行
# t=data.merge(df,left_on=data["bcr_patient_barcode"],right_on=df[0],how='left')
# class_mapping = {'Dead':0, 'Alive':1}
# t["vital_status"] = t["vital_status"].map(class_mapping)
# del t["key_0"]
# del t[0]
# t=t.dropna(axis=0,how='any')
#
# t4=t[["vital_status","last_contact_days_to","death_days_to","subtype"]].sort_values('subtype')
#
# t4.loc[t4.last_contact_days_to=='[Not Available]','last_contact_days_to']=0
# t4.loc[t4.last_contact_days_to=='[Not Applicable]','last_contact_days_to']=0
# t4.loc[t4.death_days_to=='[Not Available]','death_days_to']=0
# t4.loc[t4.death_days_to=='[Not Applicable]','death_days_to']=0
# aaa33=t4.astype(int)
# aaa33['time(day)']=aaa33['last_contact_days_to']+aaa33['death_days_to']
# a=aaa33.drop(['last_contact_days_to','death_days_to'],axis=1)
# a.to_csv('F:/zs/data/survival_process/ov_k.txt',sep='\t',index=0)
# print()
from sklearn.metrics import silhouette_score

df=pd.read_csv('E:/code/zs/data/brca/12emb/cnv_brca_patient.txt',sep='\t',header=None)
df1=pd.read_csv('E:/code/zs/data/sample_survival/brca.txt',sep='\t')
df=df.drop(1,axis=1)
df=df.set_index(0)
# for i in range(8,80):
#     for j in range(2,10):
#         db = DBSCAN(eps=i, min_samples=j).fit(df)
#         labels = db.labels_
#         if len(set(list(labels)))==5:
#             result = Counter(labels)
#             print(i,j,len(set(list(labels))),result)
clustering = DBSCAN(eps=15, min_samples=2).fit(df)
print('轮廓系数=',silhouette_score(df,clustering.labels_))
#clustering=KMeans(n_clusters=3,init='k-means++').fit(df)
#clustering=SpectralClustering(n_clusters=3,assign_labels='discretize',random_state=0).fit(df)
df['subtype'] = clustering.labels_
df=df.sort_values(by='subtype')
# a=len(df[df['subtype']==0])
# b=len(df[df['subtype']==-1])
# c=len(df[df['subtype']==2])
# d=len(df[df['subtype']==3])
# e=len(df[df['subtype']==4])
# f=len(df[df['subtype']==5])
df=df.reset_index()
data=df[[0,'subtype']]
aa=pd.merge(data,df1,left_on=df[0],right_on=df1['bcr_patient_barcode'],how='inner')
aaa=aa[[0,'time(day)','vital_status','subtype']]

aaa.to_csv('F:/zs/data/survival_process/mans/cnv_ucec_D.txt',sep='\t',index=0)
print()