
import pandas as pd
res=[]

df1=pd.read_csv('E:/code/zs/data/mutation_gene.txt',header=None,sep='\t')
df2=pd.read_csv('E:/code/zs/新建文件夹/node2vec-master/embeddings/mans_graph_emb.txt',sep=' ',header=None)
data12=pd.read_csv('E:/code/zs/data/tumor_stage/TCGA.BRCA.tumorstage.mutect.NonSilent.txt',sep='\t')
df1=df1.drop_duplicates(subset=[0,1,2],keep='first')
df1 = df1[df1[2] ==1]
df1=df1.reset_index(drop=True)#重置索引
df3=df1[0]
for zz in df3:
    res.append(zz[:12])
res = pd.DataFrame(res)
res = res.rename(columns={0: 'sample'})
df22 = pd.concat([res , df1] , axis=1)
df22=df22.drop(0,axis=1)
df22=pd.merge(df22,data12,left_on=df22.iloc[:,0],right_on=data12.iloc[:,0],how='inner')
df123=df22.drop(['key_0',2,'sample_y'],axis=1)
df2=pd.merge(df123,df2,left_on=1,right_on=0,how='inner')
df12=df2.drop([1,'1_x'],axis=1)
l = [1,2,3,4]
jj = 1
df12 = df12.set_index('sample_x')
for j in l:
    d = df12[df12['tumor_stage'] == j]
    p = d[0].drop_duplicates(keep='first')
    for z in p:
        s = (df12[0] == z).sum().sum()
        dd = d[d[0] == z]
        s1 = (dd[0] == z).sum().sum()
        dd=dd.reset_index()
        dd=dd.set_index(['sample_x',0])
        #dd = dd.groupby([dd['0_x'] , dd ['2_x']]).sum()
        D = dd * (s1 / s)
        if jj == 1:
            DD = D
            DD['label'] = j
            jj = 0
        else:
            D['label'] = j
            DD = pd.concat([DD , D])
    print('cancer=',j)

data = DD.reset_index()
data = data.drop([0 , 'tumor_stage'] , axis=1)
data=data.groupby([data['sample_x'] , data['label']]).sum()
data.to_csv('F:/zs/data/brca/12emb/cnv_brca_patient.txt',sep='\t',header=None)