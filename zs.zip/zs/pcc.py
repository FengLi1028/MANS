
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import DBSCAN , OPTICS,SpectralClustering,KMeans
from sklearn.metrics import silhouette_score
from sklearn.metrics import calinski_harabasz_score

#轮廓系数、CH系数
# silhouettteScore = []
# df=pd.read_csv('F:/zs/data/stad/12emb/stad_patient.txt',sep='\t',header=None)
# df=df.set_index(0)
# df=df.drop([1],axis=1)
# db = DBSCAN(eps=19, min_samples=6).fit(df)
# score = silhouette_score(df, db.labels_)
# score1 = calinski_harabasz_score(df, db.labels_)
# print()
#
# score_si=[]
# score_ca=[]
# df=pd.read_csv('F:/zs/data/cesc/12emb/mans_cesc_patient.txt',sep='\t',header=None)
# df1=pd.read_csv('F:/zs/data/sample_survival/cesc.txt',sep='\t')
# df=df.drop(1,axis=1)
# df=df.set_index(0)
# clustering = DBSCAN(eps=67, min_samples=7).fit(df)
# print('轮廓系数=',silhouette_score(df,clustering.labels_))
# df=pd.read_csv('F:/zs/data/cesc/12emb/cesc_patient.txt',sep='\t',header=None)
# #df=df[df[1]==1]
# df1=pd.read_csv('F:/zs/data/sample_survival/cesc.txt',sep='\t')
# df2=pd.DataFrame(df1['bcr_patient_barcode'])
# df=pd.merge(df,df2,left_on=df[0],right_on=df2['bcr_patient_barcode'],how='inner')
# df=df.drop(['key_0',1,'bcr_patient_barcode'],axis=1)
# df.to_csv('F:/zs/data/survival_process/cescsample.txt',sep='\t',index=0)
n_cluster = [2,3,4,5,6,7,8,9,10]
# gamma = [0.0001,0.001,0.01,0.1,1,10]


# for j in gamma:
#     for k in n_cluster:
#         #model=SpectralClustering(n_clusters=k,gamma=j).fit(df)
#         model = KMeans(n_clusters=3).fit(df)
#         print('gamma=',j,'k=',k,'轮廓系数=',silhouette_score(df,model.labels_),'calinski_harabasz=',calinski_harabasz_score(df,model.labels_)
#               )
#     print()


# for k in n_cluster:
#     model = KMeans(n_clusters=k,init='k-means++').fit(df)
#     print('k=',k,'轮廓系数=',silhouette_score(df,model.labels_),'calinski_harabasz=',calinski_harabasz_score(df,model.labels_)
#               )
# print()

# list1=range(2,10)
# for k in range(2,10):
#     clustering=SpectralClustering(n_clusters=k,gamma=0.001).fit(df)
#
#     score = silhouette_score(df , clustering.labels_)
#     score1 = calinski_harabasz_score(df, clustering.labels_)
#     score_si.append(score)
#     score_ca.append(score1)
#     print('轮廓系数=',score,'calinski_harabasz系数=',score1)
#
# plt.subplot(2,1,1)
# plt.plot(list1,score_si)
# plt.subplot(2,1,2)
# plt.plot(list1,score_ca)
# plt.show()
#数据对转矩阵
# df=pd.read_csv('F:/xiugaicellmatch.txt',sep=',')
# df['pmid_number']=1
# df=df.drop('pmid',axis=1)
# df = df.groupby([df['celltype'] , df['gene']]).sum()
# df=df.groupby(['celltype','gene']).first().unstack()
# df=df.fillna(0)
# df=df.astype(int)
# df.to_csv('F:/3333.txt',sep='\t',header=None)


# data=pd.read_csv('F:/szs/data/TCGA_Clinical/skcm/Clinical/nationwidechildrens.org_clinical_patient_skcm.txt', sep='\t')
# data=data[["bcr_patient_barcode","gender","vital_status","last_contact_days_to","death_days_to"]]
# data=data.drop(data[data['last_contact_days_to'].isin(['[Completed]'])].index)#删除指定元素的行
#
# class_mapping = {'Dead':0, 'Alive':1}
# data["vital_status"] = data ["vital_status"].map(class_mapping)
#
# t=data .dropna(axis=0,how='any')
#
# t4=t[["bcr_patient_barcode","vital_status","last_contact_days_to","death_days_to"]]
#
# t4.loc[t4.last_contact_days_to=='[Not Available]','last_contact_days_to']=0
# t4.loc[t4.last_contact_days_to=='[Not Applicable]','last_contact_days_to']=0
# t4.loc[t4.death_days_to=='[Not Available]','death_days_to']=0
# t4.loc[t4.death_days_to=='[Not Applicable]','death_days_to']=0
# t4=t4.set_index('bcr_patient_barcode')
# t4['death_days_to']=pd.to_numeric(t4['death_days_to'],errors='coerce')
# t4=t4.dropna()
#
# aaa33=t4.astype(int)
# aaa33['time(day)']=aaa33['last_contact_days_to']+aaa33['death_days_to']
# a=aaa33.drop(['last_contact_days_to','death_days_to'],axis=1)
# a=a.sort_values(by='time(day)')
# a=a.loc[a['time(day)']>0]
# a.to_csv('F:/zs/data/sample_survival/skcm.txt',sep='\t')







# df3=pd.read_csv('F:/zs/data/gene_result2.txt',sep='\t')
# df4=pd.read_csv('F:/zs/data/gene_result3.txt',sep='\t')
# df5=pd.read_csv('F:/zs/data/gene_result4.txt',sep='\t')
#
# df1=df1.drop(df1[df1[0].isin([0])].index)#删除指定元素的行
# df1=df1.sort_values(by=0)
# df1=df1.reset_index(drop=True)
# # df2=df2.sort_values(by='GeneID')
# # df3=df3.sort_values(by='GeneID')
# # df4=df4.sort_values(by='GeneID')
# # df5=df5.sort_values(by='GeneID')
# df2=df2[['GeneID','Symbol']]
# df3=df3[['GeneID','Symbol']]
# df4=df4[['GeneID','Symbol']]
# df5=df5[['GeneID','Symbol']]
# df=[df2,df3,df4,df5]
# result=pd.concat(df)
# result=result.reset_index(drop=True)
# df=pd.merge(df1,result,left_on=0,right_on='GeneID')
# df=df.drop(0,axis=1)
# df=df.drop_duplicates(subset=['GeneID'],keep='first')
# df=df.reset_index(drop=True)
# #df=df[1]



# df=pd.read_csv('F:/zs/data/survival_process/brca_pam.txt',sep='\t',header=None)
# #df=df[df[1]==1]
# df1=pd.read_csv('F:/zs/data/sample_survival/cesc.txt',sep='\t')
#
# df=pd.merge(df,df1,left_on=df[0],right_on=df1['bcr_patient_barcode'],how='inner')
# df=df[[0,'time(day)','vital_status',1]]
# df.to_csv('F:/zs/data/survival_process/brca_pam.txt',sep='\t',index=0)
# print()

import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import numpy as np
values = [ 2, 3, 4,5,6]
squares = [0.54, 0.48, 0.6,0.61,0.65]
plt.ylim(0,0.75)
ax=plt.gca()
x_major_locator=MultipleLocator(1)
ax.xaxis.set_major_locator(x_major_locator)
plt.xlim(1.3,6.3)
plt.plot(values, squares,marker='.')
plt.axvline(6,0,0.86,color="k", linestyle="--", linewidth=1)
plt.yticks(alpha=0)
plt.tick_params(axis='y',width=0)
plt.title('UCEC',fontsize=13)
plt.xlabel("Number of clusters",fontsize=13)
plt.ylabel("Silhouette",labelpad=-15,fontsize=13)
plt.show()
print()


