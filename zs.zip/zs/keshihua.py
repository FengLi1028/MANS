import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.cluster import DBSCAN , OPTICS , SpectralClustering
def normalization(data):
    _range = np.max(data) - np.min(data)
    dd=(data - np.min(data)) / _range
    return dd


df=pd.read_csv('F:/研究生资料/2020级孙振省/zs/data/12tumor/sample/12sample_mnas.txt',sep='\t',header=None)
#df=df[df[1]==1]
df=df.set_index([0,1])
#df=(df-df.min())/(df.max()-df.min())
#df=df.drop([1],axis=1)
#df=(df-df.mean())/df.std()

# for i in range(8,80):
#     for j in range(2,10):
#         db = OPTICS(eps=i, min_samples=j,cluster_method='dbscan').fit(df)
#         labels = db.labels_
#         if len(set(list(labels)))==2:
#             result = Counter(labels)
#             print(i,j,len(set(list(labels))),result)


# clustering=DBSCAN(eps=79, min_samples=2).fit(df)
# df['cluster_db'] = clustering.labels_



# df=df.sort_values(by='cluster_db')
df=df.reset_index()
data_zs=df.iloc[:,2:129]
tsne=TSNE()
tsne.fit_transform(data_zs)
tsne=pd.DataFrame(tsne.embedding_,index=data_zs.index)
d1=tsne[df[1]==1]
plt.scatter(d1[0],d1[1],marker='.',color='darkorange',s=3,label='BRCA')
d2=tsne[df[1]==2]
plt.scatter(d2[0],d2[1],marker='.',color='limegreen',s=3,label='CESC')
d3=tsne[df[1]==3]
plt.scatter(d3[0],d3[1],marker='.',color='royalblue',s=3,label='COAD')
d4=tsne[df[1]==4]
plt.scatter(d4[0],d4[1],marker='.',color='tan',s=3,label='HNSC')
d5=tsne[df[1]==5]
plt.scatter(d5[0],d5[1],marker='.',color='blue',s=3,label='LUAD')
d6=tsne[df[1]==6]
plt.scatter(d6[0],d6[1],marker='.',color='lightcoral',s=3,label='LUSC')
d7=tsne[df[1]==7]
plt.scatter(d7[0],d7[1],marker='.',color='red',s=3,label='OV')
d8=tsne[df[1]==8]
plt.scatter(d8[0],d8[1],marker='.',color='chocolate',s=3,label='READ')
d9=tsne[df[1]==9]
plt.scatter(d9[0],d9[1],marker='.',color='gold',s=3,label='SKCM')
d10=tsne[df[1]==10]
plt.scatter(d10[0],d10[1],marker='.',color='aqua',s=3,label='STAD')
d11=tsne[df[1]==11]
plt.scatter(d11[0],d11[1],marker='.',color='m',s=3,label='THCA')
d12=tsne[df[1]==12]
plt.scatter(d12[0],d12[1],marker='.',color='deepskyblue',s=3,label='UCEC')
# d13=tsne[data[1]==14]
# plt.scatter(d13[0],d13[1],marker='.',color='purple',s=3,label='THCA')
# d14=tsne[data[1]==15]
#plt.scatter(d14[0],d14[1],marker='.',color='palegreen',s=3,label='UCEC')
plt.legend(loc='best',frameon=False)
#plt.axis([-40,60,-40,40])
plt.show()
