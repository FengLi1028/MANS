import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.cluster import DBSCAN , OPTICS , SpectralClustering,KMeans
from lifelines.statistics import logrank_test
import numpy as np
from lifelines import KaplanMeierFitter
from sklearn.manifold import TSNE
from collections import Counter

from sklearn.metrics import silhouette_score
res=[]
df=pd.read_excel('F:/zs/新建文件夹 (2)/snf/brca.xlsx',header=None)
data=pd.read_csv('F:/zs/新建文件夹 (2)/data/lusc_cnv.txt',sep='\t',header=None)

df1=pd.read_csv('F:/zs/data/sample_survival/lusc.txt',sep='\t')

for zz in data[0]:
    res.append(zz[:12])
res = pd.DataFrame(res)
res = res.rename(columns={0: 'sample'})
df22 = pd.concat([res , df] , axis=1)



aa=pd.merge(df22,df1,left_on=df22['sample'],right_on=df1['bcr_patient_barcode'],how='inner')
aaa=aa[['sample','time(day)','vital_status',0]]
#aaa=aaa.sort_values(by=1)
aaa.to_csv('F:/zs/新建文件夹 (2)/snf/lusc.txt',sep='\t',index=0)
print()