from collections import Counter

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.cluster import DBSCAN , OPTICS , SpectralClustering
from lifelines.statistics import logrank_test
import numpy as np
from lifelines import KaplanMeierFitter
from sklearn.manifold import TSNE
def EuclideanDistances(A, B):
    BT = B.transpose()
    vecProd = np.dot(A,BT)
    SqA =  A**2
    sumSqA = np.matrix(np.sum(SqA, axis=1))
    sumSqAEx = np.tile(sumSqA.transpose(), (1, vecProd.shape[1]))
    SqB = B**2
    sumSqB = np.sum(SqB, axis=1)
    sumSqBEx = np.tile(sumSqB, (vecProd.shape[0], 1))
    SqED = sumSqBEx + sumSqAEx - 2*vecProd
    SqED[SqED<0]=0.0
    ED = np.sqrt(SqED)
    return ED


# df=pd.read_csv('F:/zs/data/read/12emb/mans_read_patient.txt',sep='\t',header=None)
# #df=df[df[1]==1]
# df=df.set_index(0)
# df=df.drop([1],axis=1)
#
# clustering=DBSCAN(eps=79, min_samples=3).fit(df)
# df['cluster_db'] = clustering.labels_
#
# df=df.sort_values(by='cluster_db')
# df=df.reset_index()
# data_zs=df.iloc[:,1:129]
# tsne=TSNE()
# tsne.fit_transform(data_zs)
# #a=tsne.fit_transform(data_zs)
# tsne=pd.DataFrame(tsne.embedding_,index=data_zs.index)
# Euclidean_dis=EuclideanDistances(tsne.values,tsne.values)
# d1=pd.DataFrame(Euclidean_dis)
# d1=-d1
# f,ax=plt.subplots(figsize=(5,4))
# sns.heatmap(d1, cmap = 'Oranges', ax = ax, vmin=-30, vmax=0,cbar = False)
# ax.set_title('UECE',fontsize=15)
# ax.set_ylim([len(d1), 0])
# plt.xticks([])
# plt.yticks([])
# plt.show()

df=pd.read_csv('E:/code/zs/data/brca/12emb/brca_patient.txt',sep='\t',header=None)
df1=pd.read_csv('E:/code/zs/data/sample_survival/brca.txt',sep='\t')

df=df.drop(1,axis=1)

df=df.set_index(0)
results = []
b=0.3
for i in range(8,80):
    for j in range(2,10):
        clustering = DBSCAN(eps=i, min_samples=j).fit(df)
        df['subtype'] = clustering.labels_
        if len(set(list(clustering.labels_))) == 2:
            df=df.sort_values(by='subtype')

            df=df.reset_index()
            data=df[[0,'subtype']]

            matching_values = set(data[0].dropna()).intersection(set(df1['bcr_patient_barcode'].dropna()))
            print("匹配的值：", matching_values)

            if 'TCGA-C8-A273' in df1['bcr_patient_barcode'].values:
                print("'TCGA-C8-A273' 存在于 df1['bcr_patient_barcode'] 列中。")
            else:
                print("'TCGA-C8-A273' 不存在于 df1['bcr_patient_barcode'] 列中。")

            aa=pd.merge(data,df1,left_on=data[0].values,right_on=df1['bcr_patient_barcode'].values,how='inner')
            df=df.set_index(0)
            aaa=aa[[0,'time(day)','vital_status','subtype']]

            t1=aaa[aaa['subtype']==-1]
            T = t1['time(day)']
            E = t1['vital_status']
            T1=T
            E1=E

            t2=aaa[aaa['subtype']==0]
            T = t2['time(day)']
            E = t2['vital_status']
            T2=T
            E2=E


            result1=logrank_test(T1,T2, event_observed_A=E1, event_observed_B=E2)
            a=result1.p_value
            if a<b:
                m=i
                n=j
                b=a
            results.append([i, j, a])
print('i=',m,'j=',n,b)

results_df = pd.DataFrame(results, columns=['eps', 'min_samples', 'p_value'])
results_df.to_csv('brca_results.csv', index=False)




