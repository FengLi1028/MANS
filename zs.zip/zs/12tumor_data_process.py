import pandas as pd
import os
a=[]
def file_name(file_dir):
    for root, dirs, files in os.walk(file_dir):
        for i in files:
            a.append(os.path.join(root, i))
#整合12种肿瘤类型数据
# df1= pd.read_csv('F:/zs/data/12tumor/cnv/read_cnv_feature.txt',sep=',',header=None,index_col=0)
# file_name('F:/zs/data/12tumor/cnv')
# for z in a[1:]:
#     df2 = pd.read_csv(z,sep=',',header=None,index_col=0)
#     df1=pd.concat([df1,df2],axis=1)
# df1.to_csv('F:/zs/data/12tumor/12cnv_feature.txt',sep='\t', header=None)




df1= pd.read_csv('E:/code/zs/data/read/read_public_gene.txt',sep='\t')
df2= pd.read_csv('E:/code/zs/data/read/methy.txt',sep='\t')
data=pd.merge(df1,df2,left_on='gene',right_on='gene',how='inner')
#data=data.drop(['sample'],axis=1)
data.to_csv('F:/zs/data/read/three_data_public_gene_feature/read_methy_feature.txt',header=None,index=0)
