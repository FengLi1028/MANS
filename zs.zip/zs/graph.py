import pandas as pd
import numpy as np
import os
#根据RF构建的网络，进行筛边

a=[]
j=0
# df=pd.read_csv('F:/zs/data/12tumor/graph_fusion/knn/knn_CNV.txt',sep='\t',index_col=0)
# df=df.where(np.triu(np.ones(df.shape)).astype(np.bool))#保留上三角
# df=df.stack().reset_index()#转为基因对并保留权重
# df.columns = ['Row','Column','Value']
# df=df[df['Value']>0.2]
# df=df.sort_values(by='Value',ascending=False)
# len=len(df)
# df=df.drop(['Value'],axis=1)
# df.to_csv('F:/zs/新建文件夹/node2vec-master/graph/cnv_affinity_graph.edgelist',sep='\t', header=None, index=0)

def file_name(file_dir):
    for root, dirs, files in os.walk(file_dir):
        for i in files:
            #a.append(i)
            a.append(os.path.join(root, i))

file_name('· /data/12tumor/graph_fusion/knn')

for i in a:
    j+=1
    df=pd.read_csv(i,sep='\t',index_col=0)
    df=df.where(np.triu(np.ones(df.shape)).astype(np.bool))#保留上三角
    df=df.stack().reset_index()#转为基因对并保留权重
    df.columns = ['Row','Column','Value']
    df=df[df['Value']>0.4]
    df=df.sort_values(by='Value',ascending=False)
    df=df.drop(['Value'],axis=1)
    if j==1:
        df1=df
    else:
        df1=pd.concat([df1,df],axis=0)
1

df1.to_csv('F:/zs/新建文件夹/node2vec-master/graph/mans_affinity_graph0.4.edgelist',sep='\t', header=None, index=0)







