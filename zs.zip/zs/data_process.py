import pandas as pd

'''
df1=pd.read_csv('F:/zs/data/ucec/123123methylation.txt',sep='\t')
df1=df1[['#id','gene']]
df1['gene']=df1['gene'].map(lambda x:x.split(','))
df=df1.explode('gene')
df2=pd.read_csv('F:/zs/data/ucec/HumanMethylation450.txt',sep='\t')
df2=df2.dropna()
df=pd.merge(df,df2,left_on=df.iloc[:,0],right_on=df2.iloc[:,0],how='inner')
df=df.drop(df[df['gene'].isin(['.'])].index)#删除指定元素的行
df=df.drop(['key_0','#id','sample'],axis=1)
df=df.groupby(df['gene']).mean()#按列求均值
df=df.reset_index()
df.to_csv('F:/zs/data/ucec/methy.txt',sep='\t',index=0)
'''
df=pd.read_csv('E:/code/zs/data/ucec/methy.txt',sep='\t')
methy=pd.DataFrame(df['gene'])
mRNA=pd.read_csv('E:/code/zs/data/ucec/mRNA.txt',sep='\t')
mrna1=pd.DataFrame(mRNA['sample'])
cnv=pd.read_csv('E:/code/zs/data/ucec/CNV.txt',sep='\t')
cnv1=pd.DataFrame(cnv['Gene Symbol'])
methy_mrna1=pd.merge(methy,mrna1,left_on='gene',right_on='sample')
three_data=pd.merge(methy_mrna1,cnv1,left_on='gene',right_on='Gene Symbol')
data=three_data['gene']

data.to_csv('F:/zs/data/ucec/ucec_public_gene.txt',sep='\t',index=0)
