import json
import lightgbm as lgb
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn import metrics
from sklearn.metrics import mean_squared_error, roc_curve
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.datasets import  make_classification


a=[]
data =pd.read_csv("E:/code/zs/data/12tumor/sample/12sample_mnas.txt",index_col=0,header=None,sep='\t')

data1 = data[1]

for i in data1:
	if i==12:#1
		a.append(1)
	else:
		j = 0
		a.append(j)

data2 = data.drop([1],axis=1)

X_train,valid_x,y_train,valid_y =train_test_split(data2,a,test_size=0.2,random_state=0)
# 创建成lgb特征的数据集格式
train = lgb.Dataset(X_train, y_train) # 将数据保存到LightGBM二进制文件将使加载更快
valid = lgb.Dataset(valid_x, valid_y, reference=train)  # 创建验证数据

parameters = {
					  #'num_leaves': [20,25,30,35,40,45,50,55,60,65],
					  #'max_depth': [-1, 1, 2,3,4,5,7,9,10,15,17,25],#-1
					  #'learning_rate': [0.01,0.03,0.05,0.06,0.07,0.1],
					  #'feature_fraction': [0.5,0.6, 0.7,0.8, 0.9,0.95,1],
					  #'bagging_fraction': [0.5,0.6, 0.7,0.8, 0.9,0.95,1],
					  #'bagging_freq': [2, 3,4, 5, 6,7, 8,9,10],
					  #'lambda_l1': [0, 0.4, 0.5,0.6,0.7,0.8,0.9],
					  #'lambda_l2': [0, 10,20,30, 40,50],
					  #'cat_smooth': [1, 10, 15, 20,30, 35,50],#1




}
gbm = lgb.LGBMClassifier(boosting_type='gbdt' ,  #gbdt,dart
						 objective = 'binary' ,
						 metric = 'auc' ,
						 verbose = 0,
						 max_depth=10,
						 num_leaves = 20,
						 learning_rate = 0.1 ,
						 bagging_fraction= 0.95,
						 bagging_freq=3,
						 feature_fraction=0.5,
						 lambda_l1= 0.4,
						 lambda_l2= 0,
						 n_jobs=6
						 )
gsearch = GridSearchCV(gbm, param_grid=parameters, scoring='roc_auc', cv=50)#n_jobs=1/cpu使用个数设置
gsearch.fit(X_train, y_train)
p=gsearch.predict_proba(valid_x)
fpr,tpr,threshold = roc_curve(valid_y,p[:,1].ravel())
# fpr=pd.DataFrame(fpr)
# tpr=pd.DataFrame(tpr)
# fpr.to_csv('F:/sss/data/sample/clustering5/double_data64/m2ucec1.txt',sep='\t',header=None,index=0)
# tpr.to_csv('F:/sss/data/sample/clustering5/double_data64/m2ucec2.txt',sep='\t',header=None,index=0)
print("Best score: %0.2f" % gsearch.best_score_)
print("最优参：")
best_parameters = gsearch.best_estimator_.get_params()
for param_name in sorted(parameters.keys()):
	print("\t%s: %r" % (param_name, best_parameters[param_name]))
print("......................................")
#fpr =pd.read_csv('F:/sss/data/sample/clustering5/single_data/mread1.txt',sep='\t',header=None)
#tpr =pd.read_csv('F:/sss/data/sample/clustering5/single_data/mread2.txt',sep='\t',header=None)
# plt.figure(figsize=(12,15))
# plt.subplots_adjust(hspace=0.3, wspace=0.3)
# plt.subplot(3,3,2)
# #plt.plot(fpr, tpr, color='darkorchid',linewidth=2.6 )
# #plt.plot(fpr, tpr, color='#8e1dcc',label='RFNE_AUC = {0:0.2f}' ''.format(gsearch.best_score_),linewidth=2.5 )
# plt.plot(fpr, tpr, color='#ff7200',label='  NES_AUC = 0.84',linewidth=2.5 )
# plt.plot(fpr, tpr, color='#77e977',label='  NBS_AUC = 0.87',linewidth=2.5 )
# plt.plot(fpr, tpr, color='#69c2e5',label='  ECC_AUC = 0.60',linewidth=2.5 )
# #plt.plot([0, 1], [0, 1], 'k--',color='black',linewidth=1)
# plt.rcParams.update({'font.size':8})
# plt.legend(loc="lower right",frameon=False)
#
# plt.text(0.65, 0.5, '',size=15)
# plt.tick_params(labelsize=10)
# plt.show()

