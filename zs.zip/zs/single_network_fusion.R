
mRNA<-read.table(file="F:/zs/data/brca/three_data_public_gene_feature/brca_mRNA_feature.txt",row.names = 1,sep=",")
CNV<-read.table(file="F:/zs/data/brca/three_data_public_gene_feature/brca_cnv_feature.txt",row.names = 1,sep=",")
methy<-read.table(file="F:/zs/data/brca/three_data_public_gene_feature/brca_methy_feature.txt",row.names = 1,sep=",")
#pcc

mRNA_pcc=cor(t(mRNA),method = "pearson")
mRNA_pcc[is.na(mRNA_pcc)] <- 0
CNV_pcc=cor(t(CNV),method = "pearson")
CNV_pcc[is.na(CNV_pcc)] <- 0
methy_pcc=cor(t(methy),method = "pearson")
methy_pcc[is.na(methy_pcc)] <- 0

#affinity network
library(ANF)

K = 20      ##number of neighbors, usually (10~30)

###
distL<- list(sqrt(1-mRNA_pcc), sqrt(1-CNV_pcc), sqrt(1-methy_pcc))

###build affinity matrix for each view:
affinityL = lapply(distL, function(x) affinity_matrix(x, K)) 

knn_mRNA=affinityL[[1]]
knn_CNV=affinityL[[2]]
knn_methy=affinityL[[3]]
three_graph=1/3*(knn_mRNA+knn_CNV+knn_methy)

write.table(three_graph,file = 'F:/zs/data/12tumor/graph_fusion/12tumor/brca_three_graph.txt',sep = '\t')

###graph fusion:
#W = ANF(affinityL, K, type = c("two-step")) #random walk

#write.table(W,file = 'F:/zs/data/12tumor/graph_fusion/graph_fusion.txt',sep = '\t',col.names = FALSE)

