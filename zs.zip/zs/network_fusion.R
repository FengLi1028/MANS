
mRNA<-read.table(file="F:/zs/data/12tumor/12mRNA_feature.txt",row.names = 1,sep="\t")
CNV<-read.table(file="F:/zs/data/12tumor/12cnv_feature.txt",row.names = 1,sep="\t")
methy<-read.table(file="F:/zs/data/12tumor/12methy_feature.txt",row.names = 1,sep="\t")
#pcc

mRNA_pcc=cor(t(mRNA),method = "pearson")
mRNA_pcc[is.na(mRNA_pcc)] <- 0
CNV_pcc=cor(t(CNV),method = "pearson")
methy_pcc=cor(t(methy),method = "pearson")
#mRNA_pcc[abs(mRNA_pcc) < 0.6] <- 0
#CNV_pcc[abs(CNV_pcc) < 0.6] <- 0
#methy_pcc[abs(methy_pcc) < 0.6] <- 0
#network fusion
library(ANF)

K = 20      ##number of neighbors, usually (10~30)

###
distL<- list(sqrt(1-mRNA_pcc), sqrt(1-CNV_pcc), sqrt(1-methy_pcc))

###build affinity matrix for each view:
affinityL = lapply(distL, function(x) affinity_matrix(x, K)) 

knn_mRNA=affinityL[[1]]
knn_CNV=affinityL[[2]]
knn_methy=affinityL[[3]]
three_graph=1/3*(knn_mRNA+knn_CNV+knn_methy)
write.table(knn_mRNA,file = 'F:/zs/data/12tumor/graph_fusion/knn_mRNA.txt',sep = '\t')
write.table(knn_CNV,file = 'F:/zs/data/12tumor/graph_fusion/knn_CNV.txt',sep = '\t')
write.table(knn_methy,file = 'F:/zs/data/12tumor/graph_fusion/knn_methy.txt',sep = '\t')
write.table(three_graph,file = 'F:/zs/data/12tumor/graph_fusion/three_graph.txt',sep = '\t')

###graph fusion:
#W = ANF(affinityL, K, type = c("two-step")) #random walk

#write.table(W,file = 'F:/zs/data/12tumor/graph_fusion/graph_fusion.txt',sep = '\t',col.names = FALSE)

