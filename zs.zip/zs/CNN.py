import pandas as pd

df1=pd.read_csv('F:/zs/data/mutation_gene.txt',header=None,sep='\t')
df2=pd.read_csv('F:/zs/新建文件夹/node2vec-master/embeddings/parameter/mans_graph_emb_d64.txt',sep=' ',header=None)
#df2=pd.read_csv('F:/zs/新建文件夹/node2vec-master/embeddings/mans_graph_emb.txt',sep=' ',header=None)
df2=pd.merge(df1,df2,left_on=1,right_on=0,how='inner')
df12=df2.drop([1,'1_x'],axis=1)
l = [1,2,3,4,5,6,7,8,9,10,11,12]
jj = 1
df12 = df12.set_index('0_x')
for j in l:
    d = df12[df12['2_x'] == j]
    p = d['0_y'].drop_duplicates(keep='first')
    for z in p:
        s = (df12['0_y'] == z).sum().sum()
        dd = d[d['0_y'] == z]
        s1 = (dd['0_y'] == z).sum().sum()
        dd=dd.reset_index()
        dd=dd.set_index(['0_x','0_y'])
        #dd = dd.groupby([dd['0_x'] , dd ['2_x']]).sum()
        D = dd * (s1 / s)
        if jj == 1:
            DD = D
            DD['label'] = j
            jj = 0
        else:
            D['label'] = j
            DD = pd.concat([DD , D])
    print('cancer=',j)

data = DD.reset_index()
data = data.drop(['0_y' , '2_x'] , axis=1)
data=data.groupby([data['0_x'] , data['label']]).sum()
data.to_csv('F:/zs/data/12tumor/sample/parameter/12sample_mnas_d64.txt',sep='\t',header=None)